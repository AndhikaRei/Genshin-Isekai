# LogKom

https://docs.google.com/document/d/1zNt-5RFxmxGlGKIUl3fmy7ALUIxxCj665AkxyMP_ors/edit

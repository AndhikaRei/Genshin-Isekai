/* Program utama */

:- include('init.pl').

